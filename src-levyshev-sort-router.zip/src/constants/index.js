export const INCREMENT = 'INCREMENT';
export const DECREMENT = 'DECREMENT';

export const TODO = 'TODO';
export const INPUT = 'INPUT';
export const ADD = 'ADD';
export const DONE = 'DONE';
export const ACTIVE = 'ACTIVE';
export const CHANGE_STATUS = 'CHANGE_STATUS';
export const SHOW_FILTER = 'SHOW_FILTER'; 
export const SHOW_SORT = 'SHOW_SORT'; 
export const ALPHA_ORDER = 'ALPHA_ORDER'; 
export const OMEGA_ORDER = 'OMEGA_ORDER'; 